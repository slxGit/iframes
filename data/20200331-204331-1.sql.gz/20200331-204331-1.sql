-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : kr_iframe
-- 
-- Part : #1
-- Date : 2020-03-31 20:43:31
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `kr_sys_hook`
-- -----------------------------
DROP TABLE IF EXISTS `kr_sys_hook`;
CREATE TABLE `kr_sys_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子描述',
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统钩子 1：是 0：否',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1:开启 0:关闭',
  `created` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='钩子表';


-- -----------------------------
-- Table structure for `kr_sys_hook_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `kr_sys_hook_plugin`;
CREATE TABLE `kr_sys_hook_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标识',
  `order` int(10) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `created` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='钩子-插件对应表';


-- -----------------------------
-- Table structure for `kr_sys_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `kr_sys_plugin`;
CREATE TABLE `kr_sys_plugin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '插件名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标题',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '插件描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `config` text NOT NULL COMMENT '配置信息',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理',
  `order` int(10) NOT NULL DEFAULT '99' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `created` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `updated` int(10) NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='插件表';

