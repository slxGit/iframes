-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : kr_iframe
-- 
-- Part : #1
-- Date : 2020-04-05 20:14:34
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `kr_sys_config`
-- -----------------------------
DROP TABLE IF EXISTS `kr_sys_config`;
CREATE TABLE `kr_sys_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(32) NOT NULL DEFAULT '',
  `type` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '类型',
  `name` varchar(32) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `value` text,
  `options` text CHARACTER SET utf8 COMMENT '配置项',
  `tips` varchar(255) CHARACTER SET utf8 DEFAULT '' COMMENT '配置提示',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1：开启 0：关闭',
  `order` int(10) NOT NULL DEFAULT '99' COMMENT '排序',
  `created` int(10) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `updated` int(10) NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- -----------------------------
-- Records of `kr_sys_config`
-- -----------------------------
INSERT INTO `kr_sys_config` VALUES ('1', 'system', 'array', 'config_group', '配置分组', 'base:基本\nsystem:系统\nupload:上传\ndatabase:数据库\nali_sms:阿里云短信\nqq_login:QQ登录\nwechat_login:微信登录\nwechat_mini:微信小程序', '', '', '1', '1', '0', '0');
INSERT INTO `kr_sys_config` VALUES ('2', 'system', 'array', 'config_type', '配置类型', 'text:单行文本\ntextarea:多行文本\nstatic:静态文本\npassword:密码\ncheckbox:复选框\nradio:单选按钮\nhidden:隐藏\nswitch:开关\narray:数组\nselect:下拉框\nimage:单张图片\nimages:多张图片\nfile:单个文件\nfiles:多个文件\nueditor:UEditor 编辑器\nlayedit:LayEdit 编辑器\nicon:字体图标\ntags:标签\nnumber:数字\nbmap:百度地图\ncolorpicker:取色器\nrange:范围', '', '', '1', '2', '0', '0');
INSERT INTO `kr_sys_config` VALUES ('3', 'system', 'text', 'bmap_ak', '百度AK', 'cR6vecccztiHQDy04uDEojNGEmRITP3t', '', '用于表单构建器生成百度地图', '1', '3', '1586071996', '1586071996');
INSERT INTO `kr_sys_config` VALUES ('21', 'upload', 'tags', 'upload_file_ext', '文件后缀', 'doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip,gz,bz2,7z', '', '允许上传的文件后缀，不填则不限制类型', '1', '1', '1586082880', '1586082880');
INSERT INTO `kr_sys_config` VALUES ('22', 'upload', 'text', 'upload_file_size', '文件大小', '0', '', '图片上传大小限制，0为不限制大小，单位：kb', '1', '2', '1586082936', '1586082936');
INSERT INTO `kr_sys_config` VALUES ('23', 'upload', 'tags', 'upload_image_ext', '图片后缀', 'gif,jpg,jpeg,bmp,png', '', '允许上传的图片后缀，不填则不限制类型', '1', '3', '1586083015', '1586083015');
INSERT INTO `kr_sys_config` VALUES ('24', 'upload', 'text', 'upload_image_size', '图片大小', '0', '', '图片上传大小限制，0为不限制大小，单位：kb', '1', '4', '1586083042', '1586083042');
INSERT INTO `kr_sys_config` VALUES ('25', 'upload', 'radio', 'upload_storage', '文件存储', 'local', 'local:本地', '', '1', '5', '1586086937', '1586086937');
INSERT INTO `kr_sys_config` VALUES ('26', 'base', 'text', 'web_site_title', '站点标题', 'KirinBDF', '', '调用方式：<code>config(\'web_site_title\')</code>', '1', '1', '1586086997', '1586086997');
INSERT INTO `kr_sys_config` VALUES ('27', 'base', 'tags', 'web_site_keywords', '站点关键词', 'KirinBDF,ThinkPHP,PHP开发框架', '', '调用方式：<code>config(\'web_site_keywords\')</code>', '1', '2', '1586087028', '1586087028');
INSERT INTO `kr_sys_config` VALUES ('28', 'base', 'textarea', 'web_site_description', '站点描述', '', '', '调用方式：<code>config(\'web_site_description\')</code>', '1', '3', '1586087063', '1586087063');
INSERT INTO `kr_sys_config` VALUES ('29', 'base', 'image', 'web_site_logo', '站点LOGO', '/uploads/images/20200405/54b00a25a0635eb056f0b9102537092c.png', '', '调用方式：<code>config(\'web_site_logo\')</code>', '1', '4', '1586087107', '1586087107');
INSERT INTO `kr_sys_config` VALUES ('30', 'base', 'text', 'web_site_copyright', '版权信息', '© 2020 KirinBDF. All rights reserved.', '', '调用方式：<code>config(\'web_site_copyright\')</code>', '1', '5', '1586087183', '1586087183');
INSERT INTO `kr_sys_config` VALUES ('31', 'base', 'text', 'web_site_icp', '备案信息', '', '', '调用方式：<code>config(\'web_site_icp\')</code>', '1', '6', '1586087211', '1586087211');
INSERT INTO `kr_sys_config` VALUES ('32', 'base', 'textarea', 'web_site_statistics', '站点统计', '', '', '调用方式：<code>config(\'web_site_statistics\')</code>', '1', '7', '1586087228', '1586087228');
INSERT INTO `kr_sys_config` VALUES ('33', 'database', 'text', 'data_backup_path', '备份根路径', '../data/', '', '路径必须以 / 结尾', '1', '1', '1586087341', '1586087341');
INSERT INTO `kr_sys_config` VALUES ('34', 'database', 'text', 'data_backup_part_size', '备份卷大小', '10485760', '', '该值用于限制压缩后的分卷最大长度。单位：B', '1', '2', '1586087361', '1586087361');
INSERT INTO `kr_sys_config` VALUES ('35', 'database', 'radio', 'data_backup_compress', '启用压缩', '1', '0:不压缩\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1', '3', '1586087422', '1586087422');
INSERT INTO `kr_sys_config` VALUES ('36', 'database', 'radio', 'data_backup_compress_level', '压缩级别', '9', '1:普通\n4:一般\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1', '4', '1586087459', '1586087459');
INSERT INTO `kr_sys_config` VALUES ('37', 'ali_sms', 'text', 'ali_sms_accesskeyid', '访问密钥', 'LTAI4FiZbRBHDuzs5WuWXRSb', '', '此处填写<code>AccessKeyId</code>，访问秘钥成对（AccessKeyId 与 AccessKeySecret）生成和使用', '1', '1', '1586087809', '1586087809');
INSERT INTO `kr_sys_config` VALUES ('38', 'ali_sms', 'text', 'ali_sms_accesskeysecret', '访问密钥', 'LgLe9JfOrccl0oO6FK2lZnMqbvoDeM', '', '此处填写<code>AccessKeySecret</code>，访问秘钥成对（AccessKeyId 与 AccessKeySecret）生成和使用', '1', '2', '1586087926', '1586087926');
INSERT INTO `kr_sys_config` VALUES ('39', 'ali_sms', 'text', 'ali_sms_signname', '短信签名', '凯麟思信息技术', '', '此处填写<code>SignName</code>', '1', '3', '1586088137', '1586088137');
INSERT INTO `kr_sys_config` VALUES ('40', 'ali_sms', 'text', 'ali_sms_templatecode', '短信模板ID', 'SMS_183415090', '', '此处填写<code>TemplateCode</code>', '1', '4', '1586088171', '1586088171');
INSERT INTO `kr_sys_config` VALUES ('41', 'qq_login', 'text', 'qq_login_appid', 'APPID', '101853268', '', '', '1', '1', '1586088348', '1586088348');
INSERT INTO `kr_sys_config` VALUES ('42', 'qq_login', 'text', 'qq_login_appkey', 'APPKEY', 'f9faac00c65e2fe1c9f30d1d2996d648', '', '', '1', '2', '1586088359', '1586088359');
INSERT INTO `kr_sys_config` VALUES ('43', 'wechat_login', 'text', 'wechat_login_appid', 'AppID', 'wxdd72cbc6df2da3e1', '', '', '1', '1', '1586088492', '1586088492');
INSERT INTO `kr_sys_config` VALUES ('44', 'wechat_login', 'text', 'wechat_login_appsecret', 'AppSecret', '6de90d44d56314b53f67bd22290855e4', '', '', '1', '2', '1586088507', '1586088507');
INSERT INTO `kr_sys_config` VALUES ('45', 'wechat_mini', 'text', 'wechat_mini_appid', 'AppID', 'wx27d489b579e931d4', '', '', '1', '1', '1586088670', '1586088670');
INSERT INTO `kr_sys_config` VALUES ('46', 'wechat_mini', 'text', 'wechat_mini_appsecret', 'AppSecret', '797c82d643145b55599be917ad5991c1', '', '', '1', '2', '1586088713', '1586088713');
