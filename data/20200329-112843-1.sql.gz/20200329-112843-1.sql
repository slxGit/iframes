-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 
-- Database : kr_iframe
-- 
-- Part : #1
-- Date : 2020-03-29 11:28:43
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `kr_cms_slider`
-- -----------------------------
DROP TABLE IF EXISTS `kr_cms_slider`;
CREATE TABLE `kr_cms_slider` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '图片地址',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 1：开启 0：关闭',
  `order` int(10) unsigned NOT NULL DEFAULT '99' COMMENT '排序',
  `created` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='滚动图片表';

