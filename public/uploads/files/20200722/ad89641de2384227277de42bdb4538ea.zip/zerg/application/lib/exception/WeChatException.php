<?php
/**
 *  文件名：WeChatException
 *  创建时间：17:35
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\lib\exception;


class WeChatException extends BaseException
{
    public $code = 400;
    public $msg = '微信服务接口调用失败';
    public $errorCode = 999;
}