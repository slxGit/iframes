<?php
/**
 *  文件名：parameterException
 *  创建时间：11:15
 *  2020/1/6
 *  Writer:Slx
 */


namespace app\lib\exception;


use think\Exception;

class ParameterException extends BaseException
{
    public $code = 400;
    public $msg = '参数错误，查询结果为空！';
    public $errorCode = 10000;
}