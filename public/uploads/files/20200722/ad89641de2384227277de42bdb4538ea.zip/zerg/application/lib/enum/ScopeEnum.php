<?php
/**
 *  文件名：ScopeEnum
 *  创建时间：10:41
 *  2020/1/9
 *  Writer:Slx
 */


namespace app\lib\enum;


class ScopeEnum
{
    const User = 16;
    const Super = 32;
}