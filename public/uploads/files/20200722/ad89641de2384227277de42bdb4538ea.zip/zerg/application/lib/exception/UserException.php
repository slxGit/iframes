<?php
/**
 *  文件名：UserException
 *  创建时间：16:50
 *  2020/1/8
 *  Writer:Slx
 */


namespace app\lib\exception;


class UserException extends BaseException
{
    public $code = 404;
    public $msg = '用户不存在';
    public $errorCode = 60000;
}