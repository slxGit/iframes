<?php
/**
 *  文件名：ForbiddenException
 *  创建时间：11:13
 *  2020/1/9
 *  Writer:Slx
 */


namespace app\lib\exception;


class ForbiddenException extends BaseException
{
    public $code = 401;
    public $msg = '权限不够！';
    public $errorCode = 10000;
}