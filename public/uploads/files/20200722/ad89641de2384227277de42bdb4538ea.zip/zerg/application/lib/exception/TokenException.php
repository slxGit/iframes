<?php
/**
 *  文件名：TokenException
 *  创建时间：11:13
 *  2020/1/8
 *  Writer:Slx
 */


namespace app\lib\exception;


use think\Exception;

class TokenException extends BaseException
{
    public $code = 404;
    public $msg = '服务器缓存异常（token令牌过期）';
    public $errorCode = 10005;
}