<?php
/**
 *  文件名：ThemeException
 *  创建时间：12:00
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\lib\exception;


class ThemeException extends BaseException
{
    public $code = 404;
    public $msg = '指定主题不存在，请检查主题id';
    public $errorCode = 30000;
}