<?php
/**
 *  文件名：ProductException
 *  创建时间：15:06
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\lib\exception;


class ProductException extends BaseException
{
    public $code = 400;
    public $msg = '指定的商品不存在';
    public $errorCode = 20000;
}