<?php
/**
 *  文件名：CategoryExeption
 *  创建时间：15:48
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\lib\exception;


class CategoryException extends BaseException
{
    public $code = 404;
    public $msg = '指定类目不存在';
    public $errorCode = 50000;
}