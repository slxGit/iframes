<?php
/**
 *  文件名：BaseException
 *  创建时间：9:55
 *  2020/1/6
 *  Writer:Slx
 */


namespace app\lib\exception;


use think\Exception;

class BaseException extends Exception
{
    // http 状态码
    public $code = 400;
    // 错误具体信息
    public $msg = '参数错误';
    // 自定义错误码
    public $errorCode = 10000;
}