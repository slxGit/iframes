<?php
/**
 *  文件名：Category
 *  创建时间：15:38
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\api\model;


class Category extends BaseModel
{
    protected $hidden = ['delete_time','update_time'];
    public function img(){
        return $this->belongsTo('Image','topic_img_id','id');
    }
}