<?php
/**
 *  文件名：Address
 *  创建时间：15:53
 *  2020/1/8
 *  Writer:Slx
 */


namespace app\api\controller\v1;


use app\api\model\User as UserModel;
use app\api\model\UserAddress;
use app\api\validate\AddressNew;
use app\api\service\Token as TokenServer;
use app\api\validate\UserException;
use app\lib\enum\ScopeEnum;
use app\lib\exception\ForbiddenException;
use app\lib\exception\TokenException;
use think\Controller;
use think\Request;

class Address extends BaseController
{
    // 前置方法
    protected $beforeActionList = [
        'checkPrimaryScope' => ['only' => 'createorupdateaddress']
    ];



    public function createOrUpdateAddress(){
        $validate = new AddressNew();
        $validate->goCheck();
        // 根据token获取uid
        $uid = TokenServer::getCurrentUid();
        // 根据uid查找用户数据，判断用户是否存在
        $user = UserModel::get($uid);
        if (!$user){
          throw new UserException();
        }
        // 获取客户地址信息
        $dataArray =  $validate->getDataByRule(input('post.'));
        $userAddress = $user->address;
        if (!$userAddress){ // 判断是添加还是修改
            $user->address()->save($dataArray);
        }else{
            $user->address->save($dataArray);
        }
        $this->return_msg('201','ok',$user);
    }

    public function getUserAddress(){
        $uid = TokenServer::getCurrentUid();
        $userAddress = UserAddress::getAddress($uid);
        $this->return_msg('200','ok',$userAddress);
    }
}