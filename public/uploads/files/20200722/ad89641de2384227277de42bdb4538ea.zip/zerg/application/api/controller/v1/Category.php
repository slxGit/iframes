<?php
/**
 *  文件名：Category
 *  创建时间：15:36
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\api\controller\v1;
use app\api\model\Category as CategoryModel;
use app\lib\exception\CategoryException;

class Category extends BaseController
{
    public function getCategories(){
        $category = CategoryModel::all([],'img');
        if (!$category){
            throw new CategoryException();
        }
        $this->return_msg('200','ok',$category);
    }
}