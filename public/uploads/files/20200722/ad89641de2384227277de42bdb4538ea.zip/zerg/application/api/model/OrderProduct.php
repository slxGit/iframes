<?php
/**
 *  文件名：OrderProduct
 *  创建时间：17:23
 *  2020/1/9
 *  Writer:Slx
 */


namespace app\api\model;


class OrderProduct extends BaseModel
{

}