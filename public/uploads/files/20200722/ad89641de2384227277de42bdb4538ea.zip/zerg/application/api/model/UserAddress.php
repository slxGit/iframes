<?php
/**
 *  文件名：UserAddress
 *  创建时间：10:09
 *  2020/1/9
 *  Writer:Slx
 */


namespace app\api\model;


use app\lib\exception\UserException;

class UserAddress extends BaseModel
{
    protected $hidden = [
        'id','delete_time','user_id'
    ];
    protected $autoWriteTimestamp = true;
    protected $updateTime = 'update_time';

    public static function getAddress($uid){
        $userAddress = self::where('user_id',$uid)->find();
        if (!$userAddress){
            $user = new UserException();
            $user->msg = '用户地址不存在！';
            $user->errorCode = 60001;
        }
        return $userAddress;
    }
}