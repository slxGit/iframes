<?php
/**
 *  文件名：Token
 *  创建时间：16:36
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\api\controller\v1;


use app\api\service\UserToken;
use app\api\validate\TokenGet;
use app\lib\exception\ParameterException;
use app\api\service\Token as TokenService;
class Token extends BaseController
{
    public function getToken($code = ''){
        (new TokenGet())->goCheck();
        $ut = new UserToken($code);
        $token = $ut->get();
        $this->return_msg('200','ok',['token'=>$token]);
    }

    public function verifyToken($token = ''){
        if (!$token){
            $parameter = new ParameterException();
            $parameter->msg = 'token不允许为空';
            throw $parameter;
        }
        $valid = TokenService::verifyToken($token);
        $this->return_msg('200','ok',['isValid'=>$valid]);
    }
}