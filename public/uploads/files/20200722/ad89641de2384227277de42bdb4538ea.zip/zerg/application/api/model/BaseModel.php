<?php
/**
 *  文件名：BaseModel
 *  创建时间：9:17
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\api\model;


use think\Model;

class BaseModel extends Model
{
    /**
     * 查询Url 然后拼接
     * @param $value
     * @return string
     */
    protected function prefixImgUrl($value,$data){
        $img_path = config('img_path');
        $finalUrl = $value;
        if ($data['from'] == 1){
            $finalUrl = $img_path.$value;
        }
        return $finalUrl;
    }

    /**
     * api 数据返回
     * @param $code  【结果码  200：正常/4**数据问题/5**服务器问题】
     * @param string $msg 【返回接口提示信息】
     * @param array $data 【返回的数据】
     */
    public function return_msg($code, $msg = '', $data = [])
    {
        $return_data['code'] = $code;
        $return_data['msg'] = $msg;
        $return_data['data'] = $data;
        echo json_encode($return_data);
        die;
    }
}