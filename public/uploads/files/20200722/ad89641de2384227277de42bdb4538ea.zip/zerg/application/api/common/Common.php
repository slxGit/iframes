<?php
/**
 *  文件名：Common
 *  创建时间：17:01
 *  2020/1/3
 *  Writer:Slx
 */


namespace app\api\common;


use think\Controller;
use think\Request;
use think\Validate;

class Common extends Controller
{
    protected $request;//处理参数
    protected $validater;//用来验证数据/参数
    protected $params;//过滤后符合要求的参数
    protected $rules = array(
        'V1.Banner' => array(
            'getbanner' => array(
                'id' => 'require|number'
            )
        )
    );

    protected function initialize()
    {
        //保留父类的初始化内容
        parent::initialize();
        $this->request = Request::instance();
        $this->params = $this->check_params($this->request);
    }

    public function check_params($arr)
    {
        //获取验证规则
        $rule = $this->rules[Request::controller()][Request::action()];
        //验证参数 返回错误
        $this->validater = new Validate($rule);
        if (!$this->validater->check($arr)) {
            $this->return_msg(400, $this->validater->getError());
        }
        //通过验证
        return $arr;
    }
    /**
     * api 数据返回
     * @param $code  【结果码  200：正常/4**数据问题/5**服务器问题】
     * @param string $msg 【返回接口提示信息】
     * @param array $data 【返回的数据】
     */
    public function return_msg($code, $msg = '', $data = [])
    {
        $return_data['code'] = $code;
        $return_data['msg'] = $msg;
        $return_data['data'] = $data;
        echo json_encode($return_data);
        die;
    }
}