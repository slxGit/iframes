<?php
/**
 *  文件名：Pay
 *  创建时间：10:34
 *  2020/1/10
 *  Writer:Slx
 */


namespace app\api\controller\v1;


use app\api\service\WxNotify;
use app\api\validate\IDMustBePositiveInt;
use app\api\service\Pay as PayService;
class Pay extends BaseController
{
    protected $beforeActionList = [
        'checkExclusiveScope' => ['only','getpreorder']
    ];
    public function getPreOrder($id = ''){
        (new IDMustBePositiveInt())->goCheck();
        $pay = new PayService($id);
        return $pay->pay();
    }

    public function receiveNotify(){
        $notify = new WxNotify();
        $notify->Handle();
    }
}