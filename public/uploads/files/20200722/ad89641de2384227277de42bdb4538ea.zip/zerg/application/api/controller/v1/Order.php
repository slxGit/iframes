<?php
/**
 *  文件名：Order
 *  创建时间：14:02
 *  2020/1/9
 *  Writer:Slx
 */


namespace app\api\controller\v1;
use app\api\service\Order as OrderService;
use app\api\service\Token as TokenServer;
use app\api\validate\IDMustBePositiveInt;
use app\api\validate\OrderPlace;
use app\api\validate\PagingParameter;
use app\api\model\Order as OrderModer;
use app\lib\exception\OrderException;

class Order extends BaseController
{

    protected $beforeActionList = [
        'checkExclusiveScope' => ['only','placeoder'],
        'checkPrimaryScope' => ['only','getdetail|getsummarybyuser']
    ];

    /**
     * 未支付订单生成快照
     * @throws \app\lib\exception\ParameterException
     */
    public function placeOder(){
        (new OrderPlace())->goCheck();
        $products = input('post.products/a');
        $uid = TokenServer::getCurrentUid();
        $order = new OrderService();
        $status = $order->place($uid,$products);
        $this->return_msg('200','ok',$status);
    }

    /**
     * 我的订单分页
     * @param int $page
     * @param int $size
     * @throws \app\lib\exception\ParameterException
     */
    public function getSummaryByUser($page = 1,$size =5){
        (new PagingParameter())->goCheck();
        $userId = TokenServer::getCurrentUid();// token
        $pagingOrder = OrderModer::getSummaryByUser($userId,$page,$size);

        if ($pagingOrder->isEmpty()){

            $this->return_msg('400','暂无订单',null);
        }
        $data = $pagingOrder->hidden(['snap_items','snap_address','prepay_id'])->toArray();

        $this->return_msg('200','ok',$data);
    }

    public function getDetail($id){
        (new IDMustBePositiveInt())->goCheck();
        $order = OrderModer::get($id);
        if (!$order){
            throw new OrderException();
        }
        $data = $order->hidden(['prepay_id']);
        $this->return_msg('200','ok',$data);
    }
}