<?php
/**
 *  文件名：Product
 *  创建时间：14:55
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\api\controller\v1;

use app\api\model\Product as ProductModel;
use app\api\validate\Count;
use app\api\validate\IDMustBePositiveInt;
use app\lib\exception\ParameterException;
use app\lib\exception\ProductException;

class Product extends BaseController
{
    public function getRecent($count = 15){
        (new Count())->goCheck();
        $products = ProductModel::getMostRecent($count);
        if (!$products){
            throw new ParameterException();
        }
        $products = $products->hidden(['summary']);
        $this->return_msg('200','ok',$products);
    }

    public function getAllInCategory($id){
        (new IDMustBePositiveInt())->goCheck();
        $products = ProductModel::getProductsByCategoryId($id);
        if (!$products){
            throw new ParameterException();
        }
        $products = $products->hidden(['summary']);
        if (count($products)<1){
            $this->return_msg('400','栏目为空',$products);
        }
        $this->return_msg('200','ok',$products);
    }

    public function getOne($id){
        (new IDMustBePositiveInt())->goCheck();
        $product = ProductModel::getProductDetail($id);
        if (!$product){
            throw new ProductException();
        }
        $this->return_msg('200','ok',$product);
    }
}