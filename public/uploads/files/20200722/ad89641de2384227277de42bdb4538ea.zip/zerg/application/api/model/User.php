<?php
/**
 *  文件名：User
 *  创建时间：16:42
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\api\model;


class User extends BaseModel
{
    public function address(){
       return  $this->hasOne('UserAddress','user_id','id');
    }

    public static function getByOpenID($openId){
        $user = self::where('openid',$openId)->find();
        return $user;
    }
}