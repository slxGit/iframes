<?php
/**
 *  文件名：Pay
 *  创建时间：10:44
 *  2020/1/10
 *  Writer:Slx
 */


namespace app\api\service;


use app\lib\enum\OrderStatuseEnum;
use app\lib\exception\OrderException;
use app\lib\exception\TokenException;
use think\Exception;
use app\api\service\Order;
use app\api\model\Order as OrderModel;
use think\Loader;
use think\Log;

Loader::import('WxPay.WxPay',EXTEND_PATH,'.Api.php');
class Pay
{
    private $orderId;
    private $orderNo;

    function __construct($orderId)
    {
        if (!$orderId){
            throw new Exception('订单号不可以为空');
        }
        $this->orderId = $orderId;
    }

    /**
     * 主方法
     * @return array
     * @throws OrderException
     * @throws TokenException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function pay(){
        $this->checkOrderValid();// 验证订单号
        // 检测库存量
        $orderService = new Order();
        $status = $orderService->checkOrderStock($this->orderId);
        if (!$status['pass']){
            return $status;
        }
       return $this->makeWxPreOrder($status['orderPrice']);
    }
    /*
     * 传入参数
     */
    private function makeWxPreOrder($totalPrice){
        $openid = Token::getCurrentTokenVar('openid');
        if (!$openid){
            throw new TokenException();
        }
        $wxOrderData = new \WxPayUnifiedOrder();
        $wxOrderData->SetOut_trade_no($this->orderNo);
        $wxOrderData->SetTrade_type('JSAPI');
        $wxOrderData->SetTotal_fee($totalPrice*100);
        $wxOrderData->SetBody('零食商贩');
        $wxOrderData->SetOpenid($openid);
        $wxOrderData->SetNotify_url(config('PAY_BACK_URL'));
        return $this->getPaySignature($wxOrderData);
    }

    /**
     * 判断 订单
     * @param $wxOrderData
     * @return array
     * @throws OrderException
     * @throws \WxPayException
     */
    private function getPaySignature($wxOrderData){
        $wxOrder = \wxPayApi::unifiedOrder($wxOrderData);
        if ($wxOrder['return_code'] != 'SUCCESS' || $wxOrder['result_code'] != 'SUCCESS'){
            Log::write($wxOrder,'error');
            Log::write('获取预支付订单失败','error');
            $order = new OrderException();
            $order->msg = $wxOrder['return_msg'];
            $order->errorCode = 80003;
            $order->code = 400;
            throw $order;
        }
        $this->recordPreOrder($wxOrder);// 订单修改prepay_id
        $signature = $this->sign($wxOrder); // 调用sign
        return $signature;
    }

    /**
     * 演签
     * @param $wxOrder
     * @return array
     */
    public function sign($wxOrder){
        $jsApiPayData = new \WxPayJsApiPay();
        $jsApiPayData->SetAppid(config('app_id'));
        $jsApiPayData->SetTimeStamp((string)time());
        $rand = md5(time() . mt_rand(0,1000));
        $jsApiPayData->SetNonceStr($rand);
        $jsApiPayData->SetPackage('prepay_id='.$wxOrder['prepay_id']);
        $jsApiPayData->SetSignType('md5');
        $sign = $jsApiPayData->MakeSign();
        $rawValues = $jsApiPayData->GetValues();
        $rawValues['paySign'] = $sign;
        unset($rawValues['appId']);
        return $rawValues;
    }

    /**
     * 订单修改prepay_id
     * @param $wxOrder
     * @throws OrderException
     */
    public function recordPreOrder($wxOrder){
        if ($wxOrder['return_code'] != 'SUCCESS' || $wxOrder['result_code'] != 'SUCCESS'){
            $order = new OrderException();
            $order->msg = $wxOrder['return_msg'];
            $order->errorCode = 80003;
            $order->code = 400;
            throw $order;
        }
        OrderModel::where('id',$this->orderId)->update([
           'prepay_id'=>$wxOrder['prepay_id']
        ]);
    }

    /**
     * 验证订单号
     */
    private function checkOrderValid(){
        $order = OrderModel::where('id',$this->orderId)->find();
        // 是否为空
        if (!$order){
            throw new OrderException();
        }
        // 是否匹配
        if (!Token::isValidOperate($order->user_id)){
            $token = new TokenException();
            $token->msg = '订单与用户不匹配';
            $token->errorCode = 10003;
            throw  $token;
        }
        // 是否支付过
        if ($order->status != OrderStatuseEnum::UNPAID){
            $order = new OrderException();
            $order->msg = '订单已经支付过了';
            $order->errorCode = 80003;
            $order->code = 400;
            throw $order;
        }
        $this->orderNo = $order->order_no;
        return true;
    }
}