<?php
/**
 *  文件名：ProductProperty
 *  创建时间：15:08
 *  2020/1/8
 *  Writer:Slx
 */


namespace app\api\model;


class ProductProperty extends BaseModel
{
    protected $hidden = [
        'product_id','delete_time','id'
    ];
}