<?php
/**
 *  文件名：WxNotify
 *  创建时间：16:04
 *  2020/1/10
 *  Writer:Slx
 */


namespace app\api\service;

use app\api\model\Product;
use app\lib\enum\OrderStatuseEnum;
use think\Db;
use think\Exception;
use think\Loader;
use app\api\model\Order as OrderModel;
use app\api\service\Order as OrderService;
use think\Log;

Loader::import('WxPay.WxPay',EXTEND_PATH,'.Api.php');
class WxNotify extends \WxPayNotify
{
    public function NotifyProcess($data, &$msg)
    {
        if ($data['result_code'] == 'SUCCESS'){
            $orderNo = $data['out_trade_no'];
            Db::startTrans();
            try{
                $order = OrderModel::where('order_no',$orderNo)->find();
                if ($order->status == 1){
                    $orService = new OrderService();
                   // 库存检测
                    $stockStatus = $orService->checkOrderStock($order->id);
                    if ($stockStatus['pass']){
                        $this->updateOrderStatus($order->id,true);
                        $this->reduceStock($stockStatus);
                    }else{
                        $this->updateOrderStatus($order->id,false);
                    }
                }
                Db::commit();
                return true;
            }catch (Exception $exception){
                Log::error($exception);
                Db::rollback();
                return false;

            }
        }else{
            return true; // 只是不要让微信继续返回
        }
    }

    private function reduceStock($stockStatus){
        foreach ($stockStatus['pStatusArray'] as $status){
            Product::where('id',$status['id'])->setDec('stock',$status['count']);
        }
    }

    private function updateOrderStatus($orderID,$success){
        $status = $success ? OrderStatuseEnum::PAID : OrderStatuseEnum::PAID_BUT_OUT_OF;
        OrderModel::where('id',$orderID)->update(['status'=>$status]);
    }
}