<?php
/**
 *  文件名：Order
 *  创建时间：17:00
 *  2020/1/9
 *  Writer:Slx
 */


namespace app\api\model;


class Order extends BaseModel
{
    protected $hidden = [
        'user_id','delete_time','update_time'
    ];
    protected $autoWriteTimestamp = true;
    // 读取器格式化返回
    public function getSnapItemsAttr($value){
        if (empty($value)){
            return null;
        }
        return json_decode($value);
    }
    // 读取器格式化返回
    public function getSnapAddressAttr($value){
        if (empty($value)){
            return null;
        }
        return json_decode($value);
    }
    public static function getSummaryByUser($uid,$page=1,$size=15){
      $page = self::where('user_id',$uid)->order('create_time desc')->paginate($size,false,['page',$page]);
      return $page;
    }
}