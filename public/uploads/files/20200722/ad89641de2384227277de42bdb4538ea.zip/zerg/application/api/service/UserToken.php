<?php
/**
 *  文件名：UserToken
 *  创建时间：16:43
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\api\service;


use app\lib\enum\ScopeEnum;
use app\lib\exception\ThemeException;
use app\lib\exception\WeChatException;
use app\api\model\User as UserModel;
use think\Exception;

class UserToken extends Token
{
    protected $code;
    protected $xpAppID;
    protected $wxAppSecret;
    protected $wxLoginUrl;

    public function __construct($code)
    {
        $this->code = $code;
        $this->xpAppID = config('app_id');
        $this->wxAppSecret = config('app_secret');
        $this->wxLoginUrl = sprintf(config('login_url'),$this->xpAppID,$this->wxAppSecret,$this->code);
    }

    public function get(){
       $result =  curl_get($this->wxLoginUrl);
        $wxResult = json_decode($result,true);
        if (empty($wxResult)){
            throw new Exception('获取session_key及openId四异常，微信内部错误');
        }else{
            $loginFail = array_key_exists('errcode',$wxResult);
            if ($loginFail){
                $this->processLoginError($wxResult);
            }else{
                return $this->grantToken($wxResult);
            }
        }
    }

    private function grantToken($wxResult){
        // 拿到openid
        $openId = $wxResult['openid'];
        $user = UserModel::getByOpenID($openId);
        // 如果存在不处理，不存在插入一条记录
        if (!empty($user)){
            $uid = $user->id;
        }else{
            $uid = $this->newUser($openId);
        }
        $cacheValue = $this->prepareCachedValue($wxResult,$uid);
        $token = $this->saveToCache($cacheValue);
        return $token;
    }

    private function saveToCache($cacheValue){
        $key = self::generateToken();
        $value = json_encode($cacheValue);
        $expire_in = config('token_expire_in');

        $request = cache($key,$value,$expire_in);
        if (!$request){
            throw new ThemeException();
        }
        return $key;
    }


    /**
     * 准备缓存的值
     * @param $wxResult
     * @param $uid
     * @return mixed
     */
    private function prepareCachedValue($wxResult,$uid){
        $cacheValue  = $wxResult;
        $cacheValue['uid'] = $uid;
        // scope = 16 代表app用户权限
        $cacheValue['scope'] = ScopeEnum::User;
        return $cacheValue;
    }

    /**
     * 创建一个user
     * @param $openId
     * @return mixed
     */
    private function newUser($openId){
        $user = UserModel::create([
            'openid' => $openId
        ]);
        return $user->id;
    }

    private function processLoginError($wxResult){
        $wechat =  new WeChatException();
        $wechat->msg = $wxResult['errmsg'];
        $wechat->errorCode = $wxResult['errcode'];
        throw $wechat;
    }
}