<?php
/**
 *  文件名：BaseController
 *  创建时间：14:07
 *  2020/1/7
 *  Writer:Slx
 */


namespace app\api\controller\v1;


use think\Controller;
use app\api\service\Token as TokenService;
class BaseController extends Controller
{
    /**
     * api 数据返回
     * @param $code  【结果码  200：正常/4**数据问题/5**服务器问题】
     * @param string $msg 【返回接口提示信息】
     * @param array $data 【返回的数据】
     */
    public function return_msg($code, $msg = '', $data = [])
    {

        $return_data['code'] = $code;
        $return_data['msg'] = $msg;
        $return_data = $data;
        echo json_encode($return_data);
        die;
    }

    /**
     * 前置方法验证用户和管理员初级权限作用于
     */
    protected function checkPrimaryScope()
    {
        TokenService::needPrimaryScope();
    }

    /**
     * 前置方法验证用户和管理员初级权限作用于
     */
    protected function checkExclusiveScope()
    {
        TokenService::needExclusiveScope();
    }
}