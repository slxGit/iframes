<?php
/**
 *  文件名：ProductImage
 *  创建时间：15:04
 *  2020/1/8
 *  Writer:Slx
 */


namespace app\api\model;


class ProductImage extends BaseModel
{
    protected $hidden = [
        'img_id','delete_time','product_id'
    ];
    public function imgUrl(){
        return $this->belongsTo('Image','img_id','id');
    }
}