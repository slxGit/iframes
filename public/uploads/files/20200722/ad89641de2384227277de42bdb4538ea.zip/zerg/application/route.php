<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\Route;
// 获取轮播图信息
    Route::get('api/:version/banner/:id','api/:version.Banner/getBanner');
// 获取所有专题简要信息
Route::get('api/:version/theme','api/:version.Theme/getSimpleList');
// 获取单个专题内的商品信息
Route::get('api/:version/theme/:id','api/:version.Theme/getComplexOne',[],['id'=>'\d+']);
// 获取最近新品 （可指定数量1-15默认15） api/:version/product/recent?count = 1
Route::get('api/:version/product/recent','api/:version.Product/getRecent');
// 根据id获取商品分类信息 api/:version/product/by_category?id=1
Route::get('api/:version/product/by_category','api/:version.Product/getAllInCategory');
// 根据id获取单个商品信息(包含商品详情，商品图片)
Route::get('api/:version/product/:id','api/:version.Product/getOne',[],['id'=>'\d+']);
// 获取分类信息
Route::get('api/:version/category/all','api/:version.Category/getCategories');
// token令牌存储获取
Route::rule('api/:version/token/user','api/:version.Token/getToken');

Route::post('api/:version/token/verify','api/:version.Token/verifyToken');
// 添加用户地址  如果有就修改没有就添加
Route::post('api/:version/address','api/:version.Address/createOrUpdateAddress');

// 获取用户地址
Route::get('api/:version/address','api/:version.Address/getUserAddress');
// 生成未支付订单
Route::post('api/:version/order','api/:version.Order/placeOder');
// 订单分页查询 参数header：token  /api/v1/order/by_user?page=1&size=3
Route::get('api/:version/order/by_user','api/:version.Order/getSummaryByUser');
// 订单详情查询 参数header：token
Route::get('api/:version/order/:id','api/:version.Order/getDetail',[],['id'=>'\d+']);
// 微信支付（未测试）
Route::post('api/:version/pay/pre_order','api/:version.Pay/getPreOrder');
// 异步回调
Route::post('api/:version/pay/notify','api/:version.Pay/receiveNotify');
