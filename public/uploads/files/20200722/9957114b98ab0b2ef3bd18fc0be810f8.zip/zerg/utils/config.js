
class Config{
    constructor(){

    }
}

Config.restUrl = 'http://www.zerg.com/api/v1/';
Config.onPay=false;  //是否启用支付

export {Config};